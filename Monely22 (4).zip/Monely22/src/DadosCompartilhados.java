public class DadosCompartilhados {
    public static String usuarioLogado = "";
}